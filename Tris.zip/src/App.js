import logo from './logo.svg';
import './App.css';
import Triangles from './Triangles';

function App() {
  return (
    <div className="h-screen">
      <Triangles/>
    </div>
  );
}

export default App;
